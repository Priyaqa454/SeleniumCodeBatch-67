package testcase;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeClass;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;

public class NewTest {
	
	int a;
	WebDriver driver ;
	String searchKeyword1 = "atomic habits by james clear";
	String searchMobile = "iphone 13";
	String searchLaptop = "Dell";
	String searchBag = " Bag color White";
	String url = "https://www.amazon.in/gp/bestsellers/?ref_=nav_cs_bestsellers";
	
  @Test(priority = 2, groups = {"smoke"})
  public void searchBook() {
	  
	  driver.findElement(By.id("twotabsearchtextbox")).clear();
	  driver.findElement(By.id("twotabsearchtextbox")).sendKeys(searchKeyword1);
	  
	  driver.findElement(By.id("nav-search-submit-button")).click();
  }
  @Test(priority = 1, groups = {"smoke"})
  public void searchIphone() {
	  
	  driver.findElement(By.id("twotabsearchtextbox")).clear();
		
	  driver.findElement(By.id("twotabsearchtextbox")).sendKeys(searchBag);
	  driver.findElement(By.id("nav-search-submit-button")).click();
	  
	  
  }
  @Test(priority = 4, groups = {"Regression","P1" })
  public void searchBags() {
	  
	  driver.findElement(By.id("twotabsearchtextbox")).clear();
		
	  driver.findElement(By.id("twotabsearchtextbox")).sendKeys(searchMobile);
	  driver.findElement(By.id("nav-search-submit-button")).click();
	  
  }
  @Test(priority = 3, groups = {"smoke"})
  public void searchLaptops() {
	  
	  driver.findElement(By.id("twotabsearchtextbox")).clear();
		
	  driver.findElement(By.id("twotabsearchtextbox")).sendKeys(searchLaptop);
	  driver.findElement(By.id("nav-search-submit-button")).click();
	  
  }
  @BeforeClass(alwaysRun=true)
  public void beforeClass() {
	  WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		
		// launch url
		driver.get(url);
		// maximize the window opened
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		
	  
  }

  @AfterClass(alwaysRun=true)
  public void afterClass() {
	 
	  driver.quit();
  }

}
