import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class DemoXpath2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
			WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		
		// launch url
		driver.get("https://www.orangehrm.com/");
		
		driver.manage().window().maximize();
		driver.findElement(By.partialLinkText("Free Demo")).click();
		// input silpa in full name text box
		driver.findElement(By.xpath("//input[@name='FullName']"))
		.sendKeys("shilpa");
		
		driver.findElement(By.xpath("//inpuast[@name=\"09Email\"]"))
		.sendKeys("abc@test.com");
		
		//driver.findElements(By.tagName("a"))
		
	}

}
