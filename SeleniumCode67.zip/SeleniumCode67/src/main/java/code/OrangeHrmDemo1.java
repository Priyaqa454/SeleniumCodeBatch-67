package code;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class OrangeHrmDemo1 {

	public static void main(String[] args) {
		
		WebDriverManager.firefoxdriver().setup();
		WebDriver driver = new FirefoxDriver();
		
		// launch url
		driver.get("https://www.orangehrm.com/en/book-a-free-demo/");
		driver.manage().window().maximize();
		WebElement countryDropdown = driver.findElement(By.cssSelector("#Form_getForm_Country"));
		
	
		Select dropDownSelect = new Select(countryDropdown);
		dropDownSelect.selectByIndex(1);
//		dropDownSelect.selectByValue("India");
//		dropDownSelect.selectByVisibleText("Japan");
		
	}

}
