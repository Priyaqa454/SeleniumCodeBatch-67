package code;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class AmazonPage {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		
		// launch url
		driver.get("https://www.amazon.in/gp/bestsellers/?ref_=nav_cs_bestsellers");
	
		driver.navigate().to("https://www.spicejet.com/");
		driver.navigate().back();
		driver.navigate().forward();
		// maximize the window opened
		driver.manage().window().maximize();
		
		Actions action = new Actions(driver);
		
		
		WebElement element = driver.findElement(By.linkText("Account & Lists"));
		
		action.moveToElement(element).build().perform();
		
	
	}

}
